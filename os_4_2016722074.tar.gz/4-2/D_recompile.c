#include <stdio.h>
#include <stdint.h> 
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/user.h>
#include <sys/mman.h>

#include <unistd.h>
#include <fcntl.h>
#include <time.h>

uint8_t* Operation;
uint8_t* compiled_code;

int segment_id;


void sharedmem_init(); 
void sharedmem_exit();
void drecompile_init();
void drecompile_exit(); 
void* drecompile(uint8_t *func);

int main(void)
{
	int (*func)(int a);
	int i;
	clock_t start, end;

	sharedmem_init();
	drecompile_init();

	start = clock();

	func = (int (*)(int a))drecompile(Operation);

	end = clock();

	drecompile_exit();
	sharedmem_exit();

	printf("total execution time: %f sec \n", (float)(end - start) / CLOCKS_PER_SEC);

	return 0;
}

void sharedmem_init()
{
	segment_id = shmget(1234, PAGE_SIZE, 0);
	compiled_code = (uint8_t*)shmat(segment_id, NULL, 0);

}

void sharedmem_exit()
{

	shmdt(compiled_code);

}

void drecompile_init(uint8_t *func)
{
	int fd;
	fd = open("D_recompile_test.o", O_RDWR);
	Operation = mmap(0, getpagesize(), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

	
}

void drecompile_exit()
{

	munmap(Operation, getpagesize());

}

void* drecompile(uint8_t* func)
{

	do
	{
		printf("%x ", *func);
	} while (*func++ != 0xC3);

#ifdef dynamic

	uint8_t* r1 = 0;
	uint8_t* r2 = 0;
	uint8_t* r3 = 0;
	

	do
	{
		if (*r1 == 0x83 && *r2 == 0xC0) {	// add
			printf("add\n");
		}
		else if (*r1 == 0x83 && *r2 == 0xE8) {	// sub
			printf("sub\n");
		}
		else if (*r1 == 0x6B && *r2 == 0xC0) {	// imul
			printf("imul\n");
		}
		else {

		}

		*r1 = *r2;
		*r2 = *r3;
		*r3 = *func;
		

		//printf("%x ", *func);
	}while (*func++ != 0xC3);

#endif // dynamic

}


